import logo from "./logo.svg";
import "./App.css";
import { Allusers } from "./components/allusers";

function App() {
  return (
    <div className="App">
      <Allusers />
    </div>
  );
}

export default App;
