import React, { useEffect, useState } from 'react'
import {Box,Container,Grid,Button,Card,Dialog,DialogContent,TextField,Typography,CardContent,MenuItem} from '@mui/material'

export const Allusers=()=> {
const [open,setOpen]=useState(false)
const [openE,setOpenE]=useState(false)
const [item,setItem]=useState("")
const [user,setUser]=useState({name:"",email:"",phone:"",age:""})

const [userData,setUserData]=useState([])
const [sortDir,setSortDir]=useState('asc')
const [sortCol,setSortCol]=useState(null)
const [err,setErr]=useState(0)
const [ind,setInd]=useState('')
const handleChange=(e)=>{
setUser({...user,[e.target.name]:e.target.value})
}
const handleOpen=()=>{
    setOpen(true)
}
const handleClose=()=>{
    setOpen(false)
}
const handleOpenE=()=>{
    setOpenE(true)
}
const handleCloseE=()=>{
    setOpenE(false)
}
const handleAdd=async (e)=>{
e.preventDefault()
setErr(0)
if(user.name===""){
    setErr(1)
    alert("Please enter name...")
}
else if(!user.email.includes('@')){
    setErr(2)
    alert("Please enter email...")
}
else if(user.phone.length!==10){
    setErr(3)
    alert("Please enter mobile...")
}
else if(user.age===""){
    setErr(4)
    alert("Please enter age...")
}
else{
setUserData([...userData,user])
handleClose()
setUser("")
}
}
const handleUpdate=async (index)=>{
console.log(ind)
console.log(index)

// const newArr = [...userData.slice(0, ind), user, ...userData.slice(ind, userData.length)];
const newArr = [...userData.slice(0,ind),user];
userData[index] = user;
console.log(newArr); 

setUserData(newArr)
handleCloseE()
setUser("")
}
console.log(userData)
const handleDelete=async(index)=>{
    console.log(index)
   
if (index > -1) { 
  userData.splice(index, 1); 
}

console.log(userData); 

setUserData([...userData])
}
const handleSort=async (colindex)=>{
   
 if(colindex===sortCol){
    setSortDir(sortDir==="asc"?"desc":"asc")
 }
 else{
    setSortCol(colindex)
    setSortDir("asc")
 }
const sortcpy=[...userData]
 sortcpy.sort((a,b)=>{
   console.log(a,"b")
   console.log(b,"b")

    switch(colindex){
       case 0:
        return sortDir==="asc"? a.name.localeCompare(b.name):b.name.localeCompare(a.name)
         case 1:
        return sortDir==="desc"? a.age.localeCompare(b.age):b.name.localeCompare(a.age)
        default:
        
        return sortDir==="asc"? a.name.localeCompare(b.name):b.name.localeCompare(a.name)
    }
 })
 setUserData([...sortcpy])

}

  return (
    <div>
        <Container maxWidth="xl">
        <Box>

<Grid
  container
  direction="row"
  justifyContent="flex-end"
  alignItems="center"
  m={2}
  p={2}
  spacing={2}
>
    <Grid item xs={12} textAlign={"end"}>
        <Button variant='contained' onClick={handleOpen}>
            Add
        </Button>
    </Grid>
    </Grid>

 <TextField size="small" select name="item" label="Search" variant="outlined" onChange={(e) => setItem(e.target.value)} sx={{ width: "20%" }}>
                <MenuItem value={""}>Select all</MenuItem>
                {userData.map((i) => (
                  <MenuItem value={i.name}>{i.name}</MenuItem>
                ))}

              </TextField>
               
       
    <Grid
  container
  direction="row"
  justifyContent="center"
  alignItems="center"
m={2}
  spacing={2}
>
<table id="mytable">
    <tr>
        <th id='1'><Button onClick={()=>handleSort(0)}>age 1-18 SORT</Button></th>
   
        <th id='2'><Button onClick={()=>handleSort(1)}>age 19-25 SORT</Button></th>
    
        <th id='3'><Button onClick={()=>handleSort(2)}>age 25-45 SORT</Button></th>
    
        <th id='4'><Button onClick={()=>handleSort(3)}>age 45+ SORT</Button></th>
    </tr>
    {item !==""?
    <tr>
        <td>
            {userData.map((i,index)=> (
                <>
                {i.name===item && i.age<=18 &&
<Card key={index} >
    <CardContent>
         {/* <Typography>Name:{index+1}</Typography> */}
    <Typography>Name:{i.name}</Typography>
    <Typography>Age:{i.age}</Typography>

    <Typography>Email:{i.email}</Typography>

    <Typography>Phone:{i.phone}</Typography>
    <br/>
    <Button onClick={()=>{
setUser({
    name:`${i.name}`,
    age:`${i.age}`,
    email:`${i.email}`,
    phone:`${i.phone}`

})
setInd(index)
handleOpenE(index)
}}>EDIT</Button>

    <Button onClick={()=>handleDelete(index)}>DELETE</Button>
</CardContent>
</Card>
}

</>
            ))}
        </td>
         <td>
            {userData.map((i,index)=> (
                <>
                {(i.name===item && i.age<=25 && i.age>=19) &&
<Card >
    <CardContent>
    <Typography>Name:{i.name}</Typography>
    <Typography>Age:{i.age}</Typography>

    <Typography>Email:{i.email}</Typography>

    <Typography>Phone:{i.phone}</Typography>
    <br/>
     <Button onClick={()=>{
setUser({
    name:`${i.name}`,
    age:`${i.age}`,
    email:`${i.email}`,
    phone:`${i.phone}`

})
setInd(index)

handleOpenE(index)
}}>EDIT</Button>
      <Button onClick={()=>handleDelete(index)}>DELETE</Button>

</CardContent>
</Card>
}

</>
            ))}
        </td>
         <td>
            {userData.map((i,index)=> (
                <>
                {(i.name===item && i.age<=45 && i.age>=26) &&
<Card >
    <CardContent>
    <Typography>Name:{i.name}</Typography>
    <Typography>Age:{i.age}</Typography>

    <Typography>Email:{i.email}</Typography>

    <Typography>Phone:{i.phone}</Typography>
    <br/>
     <Button onClick={()=>{
setUser({
    name:`${i.name}`,
    age:`${i.age}`,
    email:`${i.email}`,
    phone:`${i.phone}`

})
setInd(index)

handleOpenE(index)
}}>EDIT</Button>
       <Button onClick={()=>handleDelete(index)}>DELETE</Button>

</CardContent>
</Card>
}

</>
            ))}
        </td>
         <td>
            {userData.map((i,index)=> (
                <>
                {(i.age>=46) &&
<Card  >
    <CardContent>
    <Typography>Name:{i.name}</Typography>
    <Typography>Age:{i.age}</Typography>

    <Typography>Email:{i.email}</Typography>

    <Typography>Phone:{i.phone}</Typography>
    <br/>
        <Button onClick={()=>{
setUser({
    name:`${i.name}`,
    age:`${i.age}`,
    email:`${i.email}`,
    phone:`${i.phone}`

})
setInd(index)

handleOpenE(index)
}}>EDIT</Button>
    <Button onClick={()=>handleDelete(index)}>DELETE</Button>
</CardContent>
</Card>
}

</>
            ))}
        </td>
    </tr>
    :
     <tr>
        <td>
            {userData.map((i,index)=> (
                <>
                {i.age<=18 &&
<Card key={index} >
    <CardContent>
         {/* <Typography>Name:{index+1}</Typography> */}
    <Typography>Name:{i.name}</Typography>
    <Typography>Age:{i.age}</Typography>

    <Typography>Email:{i.email}</Typography>

    <Typography>Phone:{i.phone}</Typography>
    <br/>
    <Button onClick={()=>{
setUser({
    name:`${i.name}`,
    age:`${i.age}`,
    email:`${i.email}`,
    phone:`${i.phone}`

})
setInd(index)

handleOpenE(index)
}}>EDIT</Button>

    <Button onClick={()=>handleDelete(index)}>DELETE</Button>
</CardContent>
</Card>
}

</>
            ))}
        </td>
         <td>
            {userData.map((i,index)=> (
                <>
                {(i.age<=25 && i.age>=19) &&
<Card >
    <CardContent>
    <Typography>Name:{i.name}</Typography>
    <Typography>Age:{i.age}</Typography>

    <Typography>Email:{i.email}</Typography>

    <Typography>Phone:{i.phone}</Typography>
    <br/>
     <Button onClick={()=>{
setUser({
    name:`${i.name}`,
    age:`${i.age}`,
    email:`${i.email}`,
    phone:`${i.phone}`

})
setInd(index)

handleOpenE(index)
}}>EDIT</Button>
      <Button onClick={()=>handleDelete(index)}>DELETE</Button>

</CardContent>
</Card>
}

</>
            ))}
        </td>
         <td>
            {userData.map((i,index)=> (
                <>
                {(i.age<=45 && i.age>=26) &&
<Card >
    <CardContent>
    <Typography>Name:{i.name}</Typography>
    <Typography>Age:{i.age}</Typography>

    <Typography>Email:{i.email}</Typography>

    <Typography>Phone:{i.phone}</Typography>
    <br/>
     <Button onClick={()=>{
setUser({
    name:`${i.name}`,
    age:`${i.age}`,
    email:`${i.email}`,
    phone:`${i.phone}`

})
setInd(index)

handleOpenE(index)
}}>EDIT</Button>
       <Button onClick={()=>handleDelete(index)}>DELETE</Button>

</CardContent>
</Card>
}

</>
            ))}
        </td>
         <td>
            {userData.map((i,index)=> (
                <>
                {(i.age>=45) &&
<Card>
    <CardContent>
    <Typography>Name:{i.name}</Typography>
    <Typography>Age:{i.age}</Typography>

    <Typography>Email:{i.email}</Typography>

    <Typography>Phone:{i.phone}</Typography>
    <br/>
    <Button onClick={()=>{
setUser({
    name:`${i.name}`,
    age:`${i.age}`,
    email:`${i.email}`,
    phone:`${i.phone}`

})
setInd(index)

handleOpenE(index)
}}>EDIT</Button>
    <Button onClick={()=>handleDelete(index)}>DELETE</Button>
</CardContent>
</Card>
}

</>
            ))}
        </td>
    </tr>
    }
</table>

</Grid>
<Dialog open={open} onClose={handleClose}>
<DialogContent>
    <form>
         <Grid
  container
  direction="row"
  justifyContent="center"
  alignItems="center"

  spacing={2}
>
    <Grid item xs={6}>
        <TextField variant='outlined' name='name' value={user.name} label="Name" onChange={handleChange} err={err===1 && true}/>
        </Grid>
         <Grid item xs={6}>
<TextField variant='outlined' name='email' value={user.email} label="Email" onChange={handleChange} err={err===2 && true}/>
            
        </Grid>
         <Grid item xs={6}>
        <TextField variant='outlined' name='phone' value={user.phone} label="Phone" onChange={handleChange} err={err===3 && true} type='number'/>
        </Grid>
         <Grid item xs={6}>
        <TextField variant='outlined' name='age' value={user.age} label="Age" onChange={handleChange} type='number' err={err===4 && true}/>
        </Grid>
   
        <Grid item xs={6}>
            <Button variant='contained' onClick={handleClose}>Cancel</Button>
        </Grid>
        <Grid item xs={6}>
            <Button variant='contained' onClick={handleAdd}>Add</Button>
        </Grid>

        </Grid>
    </form>

</DialogContent>
</Dialog>
<Dialog open={openE} onClose={handleCloseE}>
<DialogContent>
    <form>
         <Grid
  container
  direction="row"
  justifyContent="center"
  alignItems="center"

  spacing={2}
>

    <Grid item xs={6}>
        <TextField variant='outlined' name='name' value={user.name} label="Name" onChange={handleChange} />
        </Grid>
         <Grid item xs={6}>
<TextField variant='outlined' name='email' value={user.email} label="Email" onChange={handleChange} />
          
        </Grid>
         <Grid item xs={6}>
        <TextField variant='outlined' name='phone' value={user.phone} label="Phone" onChange={handleChange} />
        </Grid>
         <Grid item xs={6}>
        <TextField variant='outlined' name='age' value={user.age} label="Age" onChange={handleChange} type='number'/>
        </Grid>
   
        <Grid item xs={6}>
            <Button variant='contained' onClick={handleClose}>Cancel</Button>
        </Grid>
        <Grid item xs={6}>
            <Button variant='contained' onClick={handleUpdate}>Update</Button>
        </Grid>

        </Grid>
    </form>

</DialogContent>
</Dialog>
        </Box>
        </Container>
    </div>
  )
}







